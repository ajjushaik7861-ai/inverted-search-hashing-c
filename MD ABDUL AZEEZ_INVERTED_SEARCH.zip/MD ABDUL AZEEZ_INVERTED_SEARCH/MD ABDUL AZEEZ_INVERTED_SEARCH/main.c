/* 
NAME        : MD ABDUL AZEEZ
DATE        : 27-02-2026
DESCRIPTION : This project implements an Inverted Search Engine using the concept 
              of Inverted Indexing. An Inverted Index is a data structure used 
              to map words to their locations in a set of files, enabling fast 
              and efficient searching.

              In this project, multiple text files (.txt) are processed to build 
              a database of words and their occurrences across different files. 
              The program supports creating, displaying, updating, searching, 
              and saving the database.

              The following are the main functions used in the Inverted Search project.

1. Create Database:
   Reads multiple text files provided by the user.
   Extracts words from each file and builds an inverted index.
   Stores each unique word in a main node and maintains a sub node list 
   containing file names and word counts.

2. Display Database:
   Displays all indexed words along with:
   - Number of files in which the word appears
   - File names
   - Word occurrence count in each file
   Helps the user verify the created database.

3. Update Database:
   Updates an already saved database file.
   Loads previously stored words and their file information into memory.
   Allows adding new files without losing old data.

4. Search Database:
   Searches for a given word in the database.
   Displays:
   - Number of files containing the word
   - File names
   - Word frequency in each file
   Provides fast searching using inverted indexing technique.

5. Save Database:
   Saves the current database into an output file.
   Stores all words, file counts, and word occurrences.
   Allows the database to be reused later without rebuilding.

6. Read and Validate Files:
   Validates file names entered by the user.
   Ensures files have the correct .txt extension.
   Checks for duplicate file names and empty files.
   Prevents invalid inputs during database creation.

7. Hashing Mechanism:
   Uses a hash table to efficiently store and access words.
   Words are inserted into specific index positions 
   based on their first character.
   Improves search performance.

8. Insert Main Node:
   Creates a main node for each unique word.
   Stores the word and number of files containing it.
   Links sub nodes representing file details.

9. Insert Sub Node:
   Stores file name and word count for each word.
   Maintains a linked list of file information for every word.

10. Memory Management:
    Dynamically allocates memory for nodes.
    Ensures proper linking of main and sub nodes.
    Prevents memory leaks and ensures safe execution.

11. Error Handling:
    Handles file opening errors.
    Validates user inputs.
    Checks for buffer overflows and invalid operations.
    Ensures program stability.

12. Exit Operation:
    Safely exits the program.
    Frees allocated memory.
    Displays a closing message for the user.

*/

#include "header.h"

main_node *hash_table[27]; // Global hash table array with 27 indices (a-z + non-alphabetic)

int main(int argc, char* argv[])
{
    if(argc < 2)
    {
        printf("ERROR: Missing Files\n");
        printf("Usage:\n <./a.out> <file1.txt> <file2.txt> ...\n");
        return FAILURE;
    }

    Slist *head = NULL;

    for(int i = 1; i < argc; i++)
    {
        if(extension(argv[i]) == FAILURE)
        {
            continue;
        }

        if(empty(argv[i]) == FAILURE)
        {
            continue;
        }

        if(duplicate(head, argv[i]) == FAILURE)
        {
            printf("File %s is a duplicate file\n", argv[i]);
            continue;
        }

        if(insert_at_last(&head, argv[i]) == FAILURE)
        {
            continue;
        }

        printf("File %s added to the linked list\n", argv[i]);
    }

    print_list(head);

    int option, flag = 0, count = 0;

    while(1)
    {
        printf("\n---------------------------------------------------------------\n");
        printf("           INVERTED SEARCH ENGINE - MAIN MENU\n");
        printf("---------------------------------------------------------------\n");
        printf("1. Create Database\n");
        printf("2. Display Database\n");
        printf("3. Update Database\n");
        printf("4. Search Database\n");
        printf("5. Save Database\n");
        printf("6. Exit\n");
        printf("Enter your option : ");
        scanf("%d", &option);

        switch(option)
        {
            case 1:
                if(flag == 0)
                {
                    flag = 1;
                    if(create_database(head, hash_table) == SUCCESS)
                    {
                        printf("\nSUCCESS: Files added to database successfully!\n");
                    }
                    else
                    {
                        printf("\nFAILURE: Files not added to database successfully!\n");
                    }
                }
                else
                {
                    printf("\nWARNING: Database creation already completed!\n");
                }
                break;

            case 2:
                if(display_database(hash_table) == SUCCESS)
                {
                    printf("\nData displayed successfully\n");
                }
                else
                {
                    printf("\nData not displayed\n");
                }
                break;

            case 3:
            {
                char str1[10];
                printf("Enter file name : ");
                scanf("%s", str1);

                if(extension(str1) == FAILURE)
                {
                    continue;
                }

                if(flag == 1)
                {
                    printf("\n⚠ WARNING: Database creation completed. Update not possible!\n");
                }
                else if(count == 1)
                {
                    printf("\n⚠ WARNING: Database update already completed!\n");
                }
                else
                {
                    count = 1;
                    if(update_database(&head, hash_table, str1) == SUCCESS)
                    {
                        printf("\n✓ Data updated successfully\n");
                    }
                    else
                    {
                        printf("\n✗ Data not updated\n");
                    }
                }
                break;
            }

            case 4:
                if(search_database(hash_table) == SUCCESS)
                {
                    printf("\n✓ Search completed successfully\n");
                }
                else
                {
                    printf("\n✗ Word not found in database\n");
                }
                break;

            case 5:
            {
                char str[10];
                printf("Enter file name : ");
                scanf("%s", str);

                if(extension(str) == FAILURE)
                {
                    continue;
                }

                if(save_database(hash_table, str) == SUCCESS)
                {
                    printf("\n✓ SUCCESS: Database saved to %s successfully!\n", str);
                }
                else
                {
                    printf("\n✗ FAILURE: Database not saved!\n");
                }
                break;
            }

            case 6:
                printf("\nThank you for using Inverted Search Engine!\n");
                printf("Exiting...\n\n");
                return SUCCESS;

            default:
                printf("\n✗ ERROR: Invalid option! Please try again.\n");
                break;
        }
    }
}
